package com.example.czerwiec2022;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView suma;
    int ilosc = 0;
    Button polub, usun;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


            polub = findViewById(R.id.button_polub);
            usun = findViewById(R.id.button_usun);
            suma = findViewById(R.id.suma);

            polub.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ilosc++;
                    suma.setText(ilosc + " polubien");
                }
            });

            usun.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ilosc--;
                    suma.setText(ilosc + " polubien");
                }
            });
        };




}