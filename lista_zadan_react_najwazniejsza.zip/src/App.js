import bootstrap from "bootstrap/dist/css/bootstrap.css"; 
import { useState } from "react";
import './App.css';

function ListaZadаn() {
  const [zadania, ustawZadania] = useState([]);
  const [wartośćWejściowa, ustawWartośćWejściową] = useState('');

  const obsłużZmianęWartości = (event) => {
    ustawWartośćWejściową(event.target.value);
  };

  const obsłużDodajZadanie = () => {
    if (wartośćWejściowa.trim() !== '') {
      ustawZadania([...zadania, { tekst: wartośćWejściowa}]); // dodawanie
      ustawWartośćWejściową('');
    }
  };

  const obsłużUsuńZadanie = (indeks) => {
    const noweZadania = [...zadania];
    noweZadania.splice(indeks, 1);
    ustawZadania(noweZadania);
  };

  const obsłużZaznaczZadanie = (indeks) => {
    const noweZadania = [...zadania];
    noweZadania[indeks].wykonane = !noweZadania[indeks].wykonane;
    ustawZadania(noweZadania);
  };

  return ( 
    <div className="container">

      <h1>Lista Zadań</h1>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control" placeholder="Dodaj zadanie"
          value={wartośćWejściowa}
          onChange={obsłużZmianęWartości} 
        />

        <button className="btn btn-primary" onClick={obsłużDodajZadanie}>
          Dodaj zadanie
        </button>
      </div>
      <ul className="list-group">
        {zadania.map((zadanie, indeks) => (
          <li
            key={indeks}
            className={"list-group-item"}            
          >
            <input
              type="checkbox"
              checked={zadanie.wykonane}
              onChange={() => obsłużZaznaczZadanie(indeks)}
            />
            {zadanie.tekst} 
            
            <button
              className="btn btn-danger btn-sm float-end" 
              onClick={() => obsłużUsuńZadanie(indeks)}
            >
              Usuń
            </button>
          </li>
        ))}
      </ul>
      <p>
        Liczba zadań: {zadania.length} 
        <br></br> 
        Wykonane:
        {zadania.filter((zadanie) => zadanie.wykonane).length}
      </p>
    </div>
  );
}

export default ListaZadаn;