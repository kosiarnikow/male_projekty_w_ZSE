﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace egzamin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void funkcja_pokazywananie(object sender, RoutedEventArgs e)
        {
            string numer = numer_form.Text;
            string imie = imie_form.Text;
            string nazwisko = nazwisko_form.Text;
            string kolor_oczu = "";



            if (opcja1.IsChecked == true)
            {
                kolor_oczu = "niebieskie";
            }

            else if (opcja2.IsChecked == true)
            {
                kolor_oczu = "zielone";
            }

            else if (opcja3.IsChecked == true)
            {
                kolor_oczu = "piwne";
            }

            if (imie != "" && nazwisko != "" && kolor_oczu != "")
            {
                MessageBox.Show(imie + " " + nazwisko + " kolor oczu: " + kolor_oczu);
            }
            else
            {
                MessageBox.Show("„Wprowadź inne dane dane”");
            }
        }
    }
}